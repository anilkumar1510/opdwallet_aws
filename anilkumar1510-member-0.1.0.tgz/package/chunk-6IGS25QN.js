var o={production:!0,apiBaseUrl:"/api",agoraAppId:""};export{o as a};
