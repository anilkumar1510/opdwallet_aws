var e={Digital:"DIGITAL",Uploaded:"UPLOADED"};export{e as a};
