/** @type {import('next').NextConfig} */
const nextConfig = {
  // Removed rewrites - using API route handlers instead to properly forward cookies
}

module.exports = nextConfig
